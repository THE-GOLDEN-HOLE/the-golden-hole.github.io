# THE GOLDEN HOLE — Press kit

*Celebrating Gay Adult Art*

## Fact sheet

- **Name:** THE GOLDEN HOLE. In capitals, never translated.
- **What it is:** An independent annual award for gay porn creators — gay adult creators — from the Post-Ost countries.
- **Tagline:** Celebrating Gay Adult Art
- **Season:** The first, 2026. Entries and the jury call are open; voting and award dates will be announced in the official channel.
- **Region:** Post-Ost: the former USSR, Eastern Europe and the Balkans — from Prague to Kamchatka. The former GDR does not take part.
- **Formats:** Gay adult content in any medium: video, photography, GIFs and loops, drawing and illustration, digital and 3D art, NFTs. Formats compete on equal terms.
- **Awards:** Eight: Author of the Year, Best Channel of the Year, four role awards (active, versatile, passive, dominant), the Audience Prize and the Jury Grand Prix.
- **How it is judged:** The jury reviews whole bodies of work against seven criteria: idea, image, structure, point of view, rhythm, signature and afterimage. Followers, views, income and looks do not count.
- **Jury:** Selected through an open essay contest. The founders sit as honorary jurors.
- **Prize:** A collectible NFT on the TON blockchain — a single edition carrying the date and the laureate’s name.
- **Entry:** Free, aliases welcome. There are no sponsored categories. 18+ only: everyone on camera is an adult and consented to both filming and publication.
- **Founders:** Хуястая Медиа Группа, Хуясто 18+
- **Media partners:** Парни в Теме, Gay Adult Network

## Boilerplate

### Short · 1 sentence

THE GOLDEN HOLE is an independent annual award for gay porn creators from the Post-Ost countries.

### Standard · ≈ 60 words

THE GOLDEN HOLE is the first independent annual award for gay porn creators from the Post-Ost countries. It considers gay adult content in any format — video, photography, GIFs, drawing, digital and 3D art, NFTs — and judges how a work is made, not how many followers its author has. Entry is free. Every award is a collectible NFT on the TON blockchain.

### Extended · ≈ 150 words

THE GOLDEN HOLE is the first independent annual award for gay porn creators from the Post-Ost countries: the former USSR, Eastern Europe and the Balkans. It starts from the idea that porn conceived and made by its own author has intent, craft and a point of view — the very things that make film, photography and graphic art into art. So it considers gay adult content in any format: video, photography, GIFs and loops, drawing and illustration, digital and 3D art, NFTs. A jury selected through an open essay contest judges each body of work against seven criteria, from idea to signature, and ignores follower counts, views, income and looks. Season I, in 2026, has eight awards: Author of the Year, Best Channel of the Year, four role awards, the Audience Prize and the Jury Grand Prix. Entry is free and there are no sponsored categories. Every award is a collectible NFT on the TON blockchain. The founders are Хуястая Медиа Группа and Хуясто 18+.

## How to write about us

- **Write:** THE GOLDEN HOLE  
  **Avoid:** “Golden Hole Awards”, “the Golden Hole prize”  
  The name is never translated or shortened to “Golden Hole”: “the jury of THE GOLDEN HOLE”, “THE GOLDEN HOLE laureates”.

- **Write:** gay porn, gay adult content  
  **Avoid:** gay adult cinema, gay adult film, “the adult industry”  
  The award is not only about video: photography, graphics, 3D and NFTs compete on equal terms. And we name the genre plainly, without euphemisms.

- **Write:** creator, author, gay adult creator  
  **Avoid:** actor, porn star, model, influencer  
  We reward people who conceive, shoot, photograph, draw and answer for the work themselves. “Performer” applies only to the role awards.

- **Write:** award, independent annual award  
  **Avoid:** film award, festival, beauty contest  
  It is an award with a jury and categories. Bodies are not scored — contribution is.

- **Write:** Post-Ost, the Post-Ost countries  
  **Avoid:** CIS, Russia, “Russian porn”  
  Post-Ost is the former USSR, Eastern Europe and the Balkans, four alphabets. Not one country and not a political bloc.

## Logos and images

- The files may be used without prior approval in coverage of the award. Image credit: © THE GOLDEN HOLE.
- Do not stretch, recolour or outline the mark or the wordmark. Place them on a dark background with clear space at least the height of the mark.
- Do not use the award’s materials to advertise third parties or to imply a partnership that does not exist.

## Brand style

**Colours:** Ink #0E0D0C · Paper #ECE6DA · Gold #E9B44C · Red #FF3B2A

**Typefaces (Google Fonts):**
- Sofia Sans Extra Condensed — Headlines, in capitals
- Spectral Light Italic — Accents and quotes
- Sofia Sans — Body text
- IBM Plex Mono — Captions and labels

## Contact

- goldenhole@tuta.io
- https://t.me/THE_GOLDEN_HOLE
- https://goldenhole.men
